/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

/**
 *
 * @author dell
 */
public class Student {

        private String name;

    private int id;
    
    private double cpi;

    /**
     * Get the value of cpi
     *
     * @return the value of cpi
     */
    public double getCpi() {
        return cpi;
    }

    /**
     * Set the value of cpi
     *
     * @param cpi new value of cpi
     */
    public void setCpi(double cpi) {
        this.cpi = cpi;
    }


    /**
     * Get the value of id
     *
     * @return the value of id
     */
    public int getId() {
        return id;
    }

    /**
     * Set the value of id
     *
     * @param id new value of id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{" + "name=" + name + ", id=" + id + ", cpi=" + cpi + '}';
    }
    
    
    
    public Student() {
    }

    /**
     * @param id
     * @param name
     * @param cpi
     */
     public Student(int id,String name,double cpi)
    {
    }
    
}
