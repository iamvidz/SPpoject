/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import java.util.Scanner;

/**
 *
 * @author dell
 */
public class DemoStudent {
    
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);
        //command line args
        int id1=Integer.parseInt(args[0]);
        String name1=args[1];
        double cpi1=Double.parseDouble(args[2]);
        Student s1=new Student(id1,name1,cpi1);
        System.out.println(s1);
        //runtime input
        Student s2=new Student();
        System.out.println("Enter ID:");
        s2.setId(sc.nextInt());
        System.out.println("Enter Name:");
        s2.setName(sc.next());
        System.out.println("Enter Cpi:");
        s2.setCpi(sc.nextDouble());
        System.out.println(s2);
        
    }
}
